const mongoose = require('mongoose')

const Database = ()=>{
mongoose.connect('mongodb+srv://robertjr:pg123456@cluster0.ljveogm.mongodb.net/')
.then(res=>console.log("DB Connected"))
.catch(err=>console.log("Failed"))
}

module.exports = Database




