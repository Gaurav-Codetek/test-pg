const mongoose = require("mongoose")
const {Schema} = mongoose

 const usernnameSchema = new mongoose.Schema({
    name:{
        type:String
    },
    password:{
        type:String
    }, 
    tokens:[{
        token:{
            type:String,
            required:true
        }
    }]
    
 })

 const UsernameRegister = new mongoose.model("UsernameRegister",usernnameSchema);

 module.exports = UsernameRegister