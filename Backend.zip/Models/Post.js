const mongoose = require("mongoose")
const { Schema } = mongoose

const newPost = new mongoose.Schema({
    Name: {
        type: String,
        required: true
    },

    Branch : {
        type: String,
        required: true
    },

    Caption : {
        type: String,
    },
    Hashtags : {
        type: String,
    }
})
const Post_collection = mongoose.model("User-post", newPost)

module.exports= Post_collection