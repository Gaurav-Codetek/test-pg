const jwt = require("jsonwebtoken");
const collection = require("../Models/User")

const auth = async (req, res, next) => {
    try {
        console.log("auth reached")
        const token = await req.cookies.jwt
        const verifyUser = jwt.verify(token, "secret")
        console.log(verifyUser);
        const user = await collection.findOne({ _id: verifyUser._id, "tokens.token": token })
        console.log(user)
        next();
    } catch (error) {
        res.status(401).send(error);
        console.log(error)
    }

}
module.exports = auth;